# Ancestral Threshold Bias Results

Kruskal-Wallis p-value near HOMA-IR 2.5: 3.6501e-05

| Ancestry   |   N (Full) |   N (HOMA 2.3-2.7) |   Implied Threshold | 95% CI       |
|:-----------|-----------:|-------------------:|--------------------:|:-------------|
| NHW        |        546 |                 82 |                1.47 | [1.39, 1.58] |
| NHB        |        340 |                 55 |                1.37 | [1.24, 1.48] |
| Hispanic   |        263 |                 44 |                1.28 | [1.09, 1.53] |
| NHA        |        368 |                 90 |                1.74 | [1.59, 1.89] |