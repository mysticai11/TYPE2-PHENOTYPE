# Benchmark Demolition Results

| Model           |   Spearman_Rho |   AUROC_CAP>=248 |   AUROC_CAP>=268 |
|:----------------|---------------:|-----------------:|-----------------:|
| HSI             |          0.129 |            0.587 |            0.588 |
| NAFLD-LFS       |         -0.118 |            0.551 |            0.531 |
| FLI             |          0.399 |            0.683 |            0.721 |
| TyG Index       |          0.364 |            0.638 |            0.708 |
| Elastic Net     |          0.489 |            0.722 |            0.753 |
| Random Forest   |          0.597 |            0.766 |            0.803 |
| XGBoost         |          0.581 |            0.747 |            0.783 |
| DA-SS-iVAE (Z2) |          0.545 |            0.793 |            0.794 |